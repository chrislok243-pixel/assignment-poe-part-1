# assignment-poe-part-1
CLN plumbing is to offer clients a quality service at a reasonable price and to ensure the satisfaction of its clientele. conveying the company's commitment to providing high-quality services at affordable prices while prioritizing customer satisfaction.
